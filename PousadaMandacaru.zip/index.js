const express = require('express');
const port = 3000;

const app = express();

app.use(express.json());

app.use(express.static("public"));
var i_casal = '<img src="imgs/quarto_casal.jpg" class="card-img-top" alt="...">';

var i_dois = '<img src="imgs/quarto_dois.jpg" class="card-img-top" alt="...">';

var i_quatro = '<img src="imgs/quarto_quatro.jpg" class="card-img-top" alt="...">';

const quartos = [
  { 
    img: i_casal,
    name: "Quarto com cama casal",
    price: "50 R$",
    id: 1
  },
  {
    img: i_dois,
    name: "Quarto para 2 pessoas",
    price: "80 R$",
    id: 2
  },
  {
    img: i_quatro,
    name: "Quarto para 4 pessoas",
    price: "175 R$",
    id: 2
    }
];
app.get('/quartos', (req, res) => {
  res.json(quartos);
})
app.post('/quartos', (req, res) => {
  const quarto = req.body;

  quarto.id = quartos.length + 1;

  quartos.push(quarto);
  
  res.json(quarto);
});

app.listen(3000, () => console.log('Server is running'));