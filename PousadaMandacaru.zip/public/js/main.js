import api from './service/api.js';

async function loadQuartos() {
  const quartos = await api.readAll("quartos");

  for (const quarto of quartos) {
    createQuarto(quarto);
  }
}

function createQuarto(quarto) {
  const quartoCard = `<div class="col">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"><br>${quarto.img}<br> ${quarto.name} <br> ${quarto.price}</h5>
      </div>
    </div>
  </div>`;

  const quartoGroup = document.querySelector(".quarto-group");

  quartoGroup.insertAdjacentHTML('beforeend', quartoCard);
}

loadQuartos();